
public class Publisher {
	String pubDate;
	String pubName;
	
	public Publisher(){}
	public Publisher(String pubDateIn, String pubNameIn){
		this.pubDate=pubDateIn;
		this.pubName=pubNameIn;
	}
}
