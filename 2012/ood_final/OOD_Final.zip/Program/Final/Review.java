
public class Review {
	public int rating;
	String writtenReview;
	
	void writeReview(){
		
	}
	
	void printReview(){
		
	}
	
	public Review(){}
	public Review(int ratingIn, String writtenReviewIn){
		this.rating=ratingIn;
		this.writtenReview=writtenReviewIn;
	}
}
