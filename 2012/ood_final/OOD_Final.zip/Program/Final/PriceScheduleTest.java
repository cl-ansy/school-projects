import static org.junit.Assert.*;

import org.junit.Test;


public class PriceScheduleTest {

	@Test
	public void testPriceSchedule() {
		PriceSchedule p1 = new PriceSchedule();
	}

	@Test
	public void testPriceScheduleIntInt() {
		PriceSchedule p2 = new PriceSchedule();
	}

}
