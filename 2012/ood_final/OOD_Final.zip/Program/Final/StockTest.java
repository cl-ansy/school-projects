import static org.junit.Assert.*;

import org.junit.Test;


public class StockTest {

	@Test
	public void testStock() {
		Stock stock1 = new Stock();
	}

	@Test
	public void testStockIntInt() {
		Stock stock2 = new Stock(1, 1);
	}

}
