
public class Stock {
	int quantityOnHand;
	int replenishThreshold;
	
	public Stock(){}
	public Stock(int quantityOnHandIn, int replenishThresholdIn){
		this.quantityOnHand=quantityOnHandIn;
		this.replenishThreshold=replenishThresholdIn;
	}
}
