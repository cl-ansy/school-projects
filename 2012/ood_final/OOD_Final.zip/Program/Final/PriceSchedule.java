
public class PriceSchedule {
	int discountPct;
	int price;
	
	public PriceSchedule(){}
	public PriceSchedule(int discountPctIn, int priceIn){
		this.discountPct=discountPctIn;
		this.price=priceIn;
	}
}
