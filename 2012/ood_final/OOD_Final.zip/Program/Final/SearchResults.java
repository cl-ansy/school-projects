
public class SearchResults {
	static void create(){
	}
}
