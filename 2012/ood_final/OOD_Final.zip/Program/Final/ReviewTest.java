import static org.junit.Assert.*;

import org.junit.Test;


public class ReviewTest {

	@Test
	public void testWriteReview() {
	}

	@Test
	public void testPrintReview() {
	}

	@Test
	public void testReview() {
		Review review1 = new Review();
	}

	@Test
	public void testReviewIntString() {
		Review review2 = new Review(5, "asdf");
	}
}
